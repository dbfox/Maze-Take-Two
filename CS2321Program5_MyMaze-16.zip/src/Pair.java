
public interface Pair {
   public int x = 0;
   public int getX( );
   public void setX( int newVal );
   
   public int y = 0;
   public int getY( );
   public void setY( int newVal );
}